package HasA;

public class DrowShape {

	public static void main(String[] args) {

		Point[] p = 
			{
				new Point(100,100),
				new Point(140,50),
					new Point(01600,100)
			};
		
		Triangle t = new Triangle(p);

	}

}
