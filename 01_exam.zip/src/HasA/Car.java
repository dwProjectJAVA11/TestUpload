package HasA;

public class Car {
	String color;
	int door;
	void drive()
	{
		System.out.println("drive~");
	}
	
	void stop()
	{
		System.out.println("Stop!");
	}
	
}
