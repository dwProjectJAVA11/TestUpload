package HasA;

public class SamsungSpeaker {

	void volumeUP()
	{
		System.out.println("UP");
	}
	
	void voumeDOWN()
	{
		System.out.println("DOWN");
	}
}
