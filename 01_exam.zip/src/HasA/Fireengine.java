package HasA;

public class Fireengine extends Car{

	void water()
	{
		System.out.println("Water!");
	}
	
	
	
}
