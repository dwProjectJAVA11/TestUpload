package HasA;

public class Shape {
	String color = "black";
	void draw()
	{
		System.out.println("Color : " + color);
	}
}
