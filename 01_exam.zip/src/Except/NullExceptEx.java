package Except;

public class NullExceptEx {

	public static void main(String[] args) {
		
		String data = null;
		// System.out.println(data.toString());
		// System.out.println(data);
//		if(data.equals("java"))	System.out.println("같음");
		if("java".equals(data))	System.out.println("같음");
	}

}
