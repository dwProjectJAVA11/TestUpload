package Except;

public class BalanceinsufficientException extends Exception {

	public BalanceinsufficientException() {
		super();

	}

	public BalanceinsufficientException(String message) {
		super(message);

	}

	
}
