package Except;

public class ClassCastExceptionEx {

	public static void main(String[] args) {

	//	Animal ani = new Canine();
		
//		Canine c = ani;

	}

}
