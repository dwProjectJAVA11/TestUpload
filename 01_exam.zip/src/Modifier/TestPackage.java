package Modifier;

class TestPackage {
	// default 는
	
	int a;
	boolean flag;

	TestPackage()
	{
		
	}
	
}
