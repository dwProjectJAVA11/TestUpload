package Modifier;

public class TestPackageEx {

	public static void main(String[] args) {

		TestPackage obj = new TestPackage();
		
		obj.a = 15;
		obj.flag= true;
	}

}
