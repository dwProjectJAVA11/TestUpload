package loop;

public class WhileTest2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int count = 0;
		int sum = 0;
		
		while(count<=10) {
			count++;
			sum += count;
		}
		
		System.out.println("Sum is "+sum);
		
	}

}
