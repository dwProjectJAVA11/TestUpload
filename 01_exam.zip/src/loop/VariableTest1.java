package loop;

public class VariableTest1 {
	public static void main(String[] args) {
			
		int value =10;
		int sum = value + 20;
		System.out.println(sum);

	}
}
