package Abs;

public abstract class Player {

	abstract void play(int pos);
	abstract void stop();
	
}
