package Inter;

public interface Action{
	void work();
}
