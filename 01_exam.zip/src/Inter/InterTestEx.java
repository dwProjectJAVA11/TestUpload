package Inter;

public class InterTestEx {

	public static void main(String[] args) {
		
		// A a = new A();
		// 인터페이스는 객체 생성 불가
		
		A a = new InterTest();
		
		
	}

}
