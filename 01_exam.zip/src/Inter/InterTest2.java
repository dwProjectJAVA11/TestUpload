package Inter;
public class InterTest2 implements Moveable {

	@Override
	public void checkOut(String aborrower, String date) {
		// TODO Auto-generated method stub

	}

	@Override
	public void checkIn() {
		// TODO Auto-generated method stub

	}

	@Override
	public void test() {
		// TODO Auto-generated method stub

	}

}
