package Inter;

public interface Lendable {
	
	void checkOut(String aborrower, String date);
	void checkIn();
	
}
