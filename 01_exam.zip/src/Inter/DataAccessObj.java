package Inter;

public interface DataAccessObj {
	
	void select();
	void insert();
	void update();
	void delete();
	
}
