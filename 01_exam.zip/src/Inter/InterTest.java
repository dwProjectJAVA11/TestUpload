package Inter;

public class InterTest extends C implements A,B {

	@Override
	public void method() {
		// TODO Auto-generated method stub

	}

	@Override
	public void method4() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void method5() {
		// TODO Auto-generated method stub
		
	}

}
