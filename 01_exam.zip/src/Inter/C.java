package Inter;

public class C {
	public void method6()
	{
		
	}
}
