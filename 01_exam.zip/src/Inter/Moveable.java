package Inter;

public interface Moveable extends Lendable {
	
	void test();
	
}
