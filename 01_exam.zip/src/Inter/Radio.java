package Inter;

public class Radio implements RemoteContol{
	
	@Override
	public void turnON() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void turnOFF() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setVolum(int volume) {
		// TODO Auto-generated method stub
		
	}

}
