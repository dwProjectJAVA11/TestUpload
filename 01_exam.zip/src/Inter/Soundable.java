package Inter;

public interface Soundable {
	String sound();
}
