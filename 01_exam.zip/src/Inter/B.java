package Inter;

public interface B {
	void method4();
	void method5();
}
