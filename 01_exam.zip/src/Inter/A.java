package Inter;

public interface A {
	int spade = 4;
	public static final int DIA = 3;
	String str = "";
	
	void method();
	
}
