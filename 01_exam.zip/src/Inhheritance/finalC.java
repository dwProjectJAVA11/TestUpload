package Inhheritance;

public final class finalC {

	//  final : 상속ㄷ금지
	// final 메소드 : 오버라이딩 금지
	// protected ㅣ  
}

