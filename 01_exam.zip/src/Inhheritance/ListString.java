package Inhheritance;

public class ListString {
	
	String name;
	public void list()
	{
		System.out.println(name+"상위클래스");
	}
	
	public void write()
	{
		System.out.println();
	}
}

