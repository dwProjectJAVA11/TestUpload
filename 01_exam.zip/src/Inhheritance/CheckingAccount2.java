package Inhheritance;

public class CheckingAccount2 extends Account2 {

	public CheckingAccount2(String accountNum, String name, int balance) {
		super(accountNum, name, balance);
		// TODO Auto-generated constructor stub
	}
	
}
