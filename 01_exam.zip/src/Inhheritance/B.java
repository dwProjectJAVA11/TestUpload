package Inhheritance;

public class B extends A {
	private int a;
	
	B()
	{
		
	}
	
	public B(int a) {
		super();
		this.a = a;
	}



	public void average()
	{
		this.str2 = "Hello";
		
		System.out.println("평균");
	}
}
