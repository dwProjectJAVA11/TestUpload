package exam;

import java.util.Scanner;

//import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		System.out.println("Hello World");
		Scanner sc = new Scanner(System.in);

	}

}
