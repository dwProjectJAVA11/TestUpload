package CLS;

public class PersonEx {

	public static void main(String[] args) {

		Person p = new Person();
		//p.nation = "America";
		p.name = "홍길동";
	}

}
