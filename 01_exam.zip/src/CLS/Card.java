package CLS;

public class Card {
	
	String  kind;
	int number;
	
	static int width = 100;
	static int height = 200;
	
}
