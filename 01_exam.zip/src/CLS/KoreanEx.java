package CLS;

public class KoreanEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Korean obj = new Korean("홍길동", "010101-3121212");
		
	}

}
