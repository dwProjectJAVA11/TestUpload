package CLS;

public class MethodTest {

	public static void main(String[] args) {
		
		MethodTest obj = new MethodTest();
		obj.print();
		
		print();
		
	}
	
	static void print()
	{
		System.out.println("출력문");
	}
}
