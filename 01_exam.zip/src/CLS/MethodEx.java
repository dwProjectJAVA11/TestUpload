package CLS;

public class MethodEx {

	public static void main(String[] args) {

		MethodTest2 obj = new MethodTest2();
		
		// 객체가 가지고 있는 메소드를 호출
		obj.print(15,25);
		System.out.println("===============");
	}

}
