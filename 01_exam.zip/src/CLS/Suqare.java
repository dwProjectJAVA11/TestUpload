package CLS;

public class Suqare {
	
	int side_length;
	
	void Square()
	{
		
	}
	
	double getArea()
	{
		return side_length*side_length;
	}
	
}
