package CLS;

public class Triangle {
	int base_line;
	int height;
	
	Triangle()
	{
		
	}
	
	double getArea()
	{
		return (base_line*height)/2;
	}
}
