package CLS;

public class Calculator {
	
	void powerOn()
	{
		System.out.println("Power On!"); 
	}
	
	int plus(int x, int y)
	{
		return x + y;
	}
	
	double divide(int x, int y)
	{
		return (double)x / (double)y;
	}
	
	void powerOff()
	{
		System.out.println("Power Off!"); 
	}
}
