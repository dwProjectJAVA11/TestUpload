package CLS;

public class Circle {
	
	int radius;
	
	Circle()
	{
		
	}
	
	
	double GetArea()
	{
		return radius*radius*3.14;
	}
}
