package CLS;

public class Person {

	final String nation="Korea";
	final String ssn="12563";
	String name;

	// final로 선언된 변수는 생성자를 이용해서 초기화함
	// 생성자를 사용하지 않을 경우, 직접 값을 할당하여 초기화한다.
	
	/*public Person(String nation, String ssn, String name)
	{
		this.nation = nation;
		this.ssn = ssn;
		this.name = name;
	}*/
}
