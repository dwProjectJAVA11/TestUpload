package CLS;

public class Earth2 {

	void test()
	{
		String str = new String();
		
	}
	
}
