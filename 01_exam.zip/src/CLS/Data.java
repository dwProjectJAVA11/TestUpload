package CLS;

public class Data {

	int x;
	
}
