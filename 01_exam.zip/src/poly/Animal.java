package poly;

public class Animal {

	Animal()
	{
		System.out.println("Animal 생성자");
	}	
}
