package poly;

public class Dog extends Canine{
	Dog()
	{
		System.out.println("Dog 생성자");
	}
}
