package poly;

public class Canine extends Animal{

	Canine()
	{
		System.out.println("Canine");
	}
}
