package poly;

import HasA.Car;

public class Ambulance extends Car{

	void siren()
	{
		System.out.println("siren!!!");
	}
}
