package poly;

public class Feline extends Animal {
	Feline()
	{
		System.out.println("Feline 생성자");
	}
}
