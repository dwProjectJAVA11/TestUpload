package poly;

public class Lion extends Feline{
	Lion()
	{
		System.out.println("Lion");
	}
}
