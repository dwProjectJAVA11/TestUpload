package poly;

public class Parent {

	public void method1()
	{
		System.out.println("parent-method1");
	}
	
	public void method2()
	{
		System.out.println("parent-methods2");
	}

	
}
