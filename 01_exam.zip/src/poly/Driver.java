package poly;

import HasA.Vehicle;

public class Driver {
	
	public void drive(Vehicle v)
	{
		v.run();
	}
	
}
