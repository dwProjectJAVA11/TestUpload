package Poly2;

public class ChildB extends ParentA{

	@Override
	public void method1()
	{
		System.out.println("childB method1()");
	}
	
}
