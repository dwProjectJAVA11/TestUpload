package Poly2;

public class ParentA {

	private int num;
	
	public ParentA()
	{
	
	}
	
	public ParentA(int num)
	{
		this.num = num;
	}

	public void method1()
	{
		System.out.println("num : " + num);
	}
	
}
