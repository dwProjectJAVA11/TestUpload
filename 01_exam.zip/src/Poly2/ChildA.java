package Poly2;

public class ChildA extends ParentA{

	@Override
	public void method1()
	{
		System.out.println("childA method1()");
	}
	
}
